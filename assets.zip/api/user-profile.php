<?php
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../classes/Database.php';

$db = new Database();
$response = ['success' => false, 'message' => ''];

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        try {
            $user_id = $_SESSION['user_id'];
            $sql = "SELECT id, name, email, cpf, phone, address, profile_image, created_at 
                    FROM users WHERE id = ?";
            $user = $db->fetch($sql, [$user_id]);
            
            if ($user) {
                // Remove dados sensíveis
                unset($user['password']);
                
                $response = [
                    'success' => true,
                    'data' => $user
                ];
            } else {
                throw new Exception('Usuário não encontrado');
            }
        } catch (Exception $e) {
            $response['message'] = 'Erro ao carregar perfil: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'PUT':
        try {
            $user_id = $_SESSION['user_id'];
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Campos permitidos para atualização
            $allowed_fields = ['name', 'phone', 'address'];
            $update_data = array_intersect_key($data, array_flip($allowed_fields));
            
            if (!empty($update_data)) {
                $db->update('users', $update_data, 'id = ?', [$user_id]);
                
                $response = [
                    'success' => true,
                    'message' => 'Perfil atualizado com sucesso'
                ];
            } else {
                throw new Exception('Nenhum dado válido para atualização');
            }
        } catch (Exception $e) {
            $response['message'] = 'Erro ao atualizar perfil: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'POST':
        // Upload de foto de perfil
        try {
            $user_id = $_SESSION['user_id'];
            
            if (!isset($_FILES['profile_image'])) {
                throw new Exception('Nenhuma imagem enviada');
            }
            
            $file = $_FILES['profile_image'];
            $allowed_types = ['image/jpeg', 'image/png'];
            
            if (!in_array($file['type'], $allowed_types)) {
                throw new Exception('Tipo de arquivo não permitido');
            }
            
            $upload_dir = '../uploads/profile/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $filename = uniqid() . '_' . $file['name'];
            $filepath = $upload_dir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $db->update('users', 
                    ['profile_image' => 'uploads/profile/' . $filename], 
                    'id = ?', 
                    [$user_id]
                );
                
                $response = [
                    'success' => true,
                    'message' => 'Foto de perfil atualizada com sucesso',
                    'data' => ['profile_image' => 'uploads/profile/' . $filename]
                ];
            } else {
                throw new Exception('Erro ao fazer upload da imagem');
            }
        } catch (Exception $e) {
            $response['message'] = 'Erro ao atualizar foto: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
