<?php
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../classes/Database.php';

$db = new Database();
$response = ['success' => false, 'message' => ''];

function createSlug($title) {
    $slug = strtolower($title);
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    return trim($slug, '-');
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        try {
            $sql = "SELECT b.*, u.username as author_name 
                FROM blog_posts b 
                LEFT JOIN users u ON b.author_id = u.id 
                ORDER BY b.created_at DESC";
            $posts = $db->fetchAll($sql);
            
            $response = [
                'success' => true,
                'data' => $posts
            ];
        } catch (Exception $e) {
            $response['message'] = 'Error fetching blog posts: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'POST':
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $auth = new Auth();
            $user = $auth->getCurrentUser();
            
            if (!$data['title'] || !$data['content']) {
                throw new Exception('Title and content are required');
            }
            
            $data['slug'] = createSlug($data['title']);
            $data['author_id'] = $user['id'];
            
            $id = $db->insert('blog_posts', $data);
            
            $response = [
                'success' => true,
                'message' => 'Post created successfully',
                'data' => ['id' => $id]
            ];
        } catch (Exception $e) {
            $response['message'] = 'Error creating blog post: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'PUT':
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $id = $_GET['id'] ?? null;
            
            if (!$id) {
                throw new Exception('Post ID is required');
            }
            
            if (isset($data['title'])) {
                $data['slug'] = createSlug($data['title']);
            }
            
            $db->update('blog_posts', $data, 'id = ?', [$id]);
            
            $response = [
                'success' => true,
                'message' => 'Post updated successfully'
            ];
        } catch (Exception $e) {
            $response['message'] = 'Error updating blog post: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'DELETE':
        try {
            $id = $_GET['id'] ?? null;
            
            if (!$id) {
                throw new Exception('Post ID is required');
            }
            
            $db->delete('blog_posts', 'id = ?', [$id]);
            
            $response = [
                'success' => true,
                'message' => 'Post deleted successfully'
            ];
        } catch (Exception $e) {
            $response['message'] = 'Error deleting blog post: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
