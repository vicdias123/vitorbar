<?php
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../classes/Database.php';

$db = new Database();
$response = ['success' => true, 'data' => []];

try {
    // Get total leads count
    $sql = "SELECT 
        COUNT(*) as total_leads,
        SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as new_leads,
        SUM(CASE WHEN status = 'contacted' THEN 1 ELSE 0 END) as contacted_leads,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_leads,
        SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_leads
    FROM leads";
    $leadStats = $db->fetch($sql);
    
    // Get blog post stats
    $sql = "SELECT 
        COUNT(*) as total_posts,
        SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published_posts,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft_posts
    FROM blog_posts";
    $blogStats = $db->fetch($sql);
    
    // Get recent leads
    $sql = "SELECT l.*, u.username as assigned_to_name 
        FROM leads l 
        LEFT JOIN users u ON l.assigned_to = u.id 
        ORDER BY l.created_at DESC 
        LIMIT 5";
    $recentLeads = $db->fetchAll($sql);
    
    // Get recent blog posts
    $sql = "SELECT b.*, u.username as author_name 
        FROM blog_posts b 
        LEFT JOIN users u ON b.author_id = u.id 
        ORDER BY b.created_at DESC 
        LIMIT 5";
    $recentPosts = $db->fetchAll($sql);
    
    $response['data'] = [
        'stats' => [
            'leads' => $leadStats,
            'blog' => $blogStats
        ],
        'recent' => [
            'leads' => $recentLeads,
            'posts' => $recentPosts
        ]
    ];
    
} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => 'Error fetching dashboard data: ' . $e->getMessage()
    ];
    http_response_code(500);
}

header('Content-Type: application/json');
echo json_encode($response);
?>
