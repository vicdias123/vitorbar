<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../classes/Auth.php';

$auth = new Auth();
$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (isset($data['username']) && isset($data['password'])) {
        if ($auth->login($data['username'], $data['password'])) {
            $user = $auth->getCurrentUser();
            $response = [
                'success' => true,
                'message' => 'Login successful',
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'role' => $user['role']
                ]
            ];
        } else {
            $response['message'] = 'Invalid credentials';
        }
    } else {
        $response['message'] = 'Username and password are required';
    }
} else {
    $response['message'] = 'Invalid request method';
}

echo json_encode($response);
?>
