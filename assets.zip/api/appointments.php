<?php
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../classes/Database.php';

$db = new Database();
$response = ['success' => false, 'message' => ''];

// Verifica disponibilidade
function checkAvailability($db, $lawyer_id, $appointment_date) {
    $sql = "SELECT COUNT(*) as count FROM appointments 
            WHERE lawyer_id = ? 
            AND appointment_date = ? 
            AND status != 'cancelled'";
    $result = $db->fetch($sql, [$lawyer_id, $appointment_date]);
    return $result['count'] == 0;
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        try {
            $user = $_SESSION['user_id'];
            $role = $_SESSION['role'];
            
            // Se for advogado, mostra seus agendamentos
            if ($role === 'lawyer') {
                $sql = "SELECT a.*, u.name as client_name, u.email as client_email 
                        FROM appointments a 
                        JOIN users u ON a.client_id = u.id 
                        WHERE a.lawyer_id = ?
                        ORDER BY a.appointment_date DESC";
                $appointments = $db->fetchAll($sql, [$user]);
            }
            // Se for cliente, mostra apenas seus agendamentos
            else {
                $sql = "SELECT a.*, u.name as lawyer_name 
                        FROM appointments a 
                        JOIN users u ON a.lawyer_id = u.id 
                        WHERE a.client_id = ?
                        ORDER BY a.appointment_date DESC";
                $appointments = $db->fetchAll($sql, [$user]);
            }
            
            $response = [
                'success' => true,
                'data' => $appointments
            ];
        } catch (Exception $e) {
            $response['message'] = 'Erro ao buscar agendamentos: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'POST':
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['lawyer_id']) || !isset($data['appointment_date']) || !isset($data['service_type'])) {
                throw new Exception('Dados incompletos para o agendamento');
            }
            
            // Verifica disponibilidade
            if (!checkAvailability($db, $data['lawyer_id'], $data['appointment_date'])) {
                throw new Exception('Horário não disponível');
            }
            
            $data['client_id'] = $_SESSION['user_id'];
            $id = $db->insert('appointments', $data);
            
            // Envia e-mail de confirmação
            // TODO: Implementar envio de e-mail
            
            $response = [
                'success' => true,
                'message' => 'Agendamento realizado com sucesso',
                'data' => ['id' => $id]
            ];
        } catch (Exception $e) {
            $response['message'] = 'Erro ao criar agendamento: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'PUT':
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $id = $_GET['id'] ?? null;
            
            if (!$id) {
                throw new Exception('ID do agendamento é necessário');
            }
            
            // Verifica permissão
            $appointment = $db->fetch("SELECT * FROM appointments WHERE id = ?", [$id]);
            if (!$appointment || ($appointment['client_id'] != $_SESSION['user_id'] && 
                $appointment['lawyer_id'] != $_SESSION['user_id'] && $_SESSION['role'] != 'admin')) {
                throw new Exception('Permissão negada');
            }
            
            $db->update('appointments', $data, 'id = ?', [$id]);
            
            $response = [
                'success' => true,
                'message' => 'Agendamento atualizado com sucesso'
            ];
        } catch (Exception $e) {
            $response['message'] = 'Erro ao atualizar agendamento: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
        
    case 'DELETE':
        try {
            $id = $_GET['id'] ?? null;
            
            if (!$id) {
                throw new Exception('ID do agendamento é necessário');
            }
            
            // Verifica permissão
            $appointment = $db->fetch("SELECT * FROM appointments WHERE id = ?", [$id]);
            if (!$appointment || ($appointment['client_id'] != $_SESSION['user_id'] && 
                $appointment['lawyer_id'] != $_SESSION['user_id'] && $_SESSION['role'] != 'admin')) {
                throw new Exception('Permissão negada');
            }
            
            // Soft delete - apenas muda o status para cancelado
            $db->update('appointments', ['status' => 'cancelled'], 'id = ?', [$id]);
            
            $response = [
                'success' => true,
                'message' => 'Agendamento cancelado com sucesso'
            ];
        } catch (Exception $e) {
            $response['message'] = 'Erro ao cancelar agendamento: ' . $e->getMessage();
            http_response_code(500);
        }
        break;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
