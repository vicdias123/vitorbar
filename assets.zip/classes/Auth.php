<?php
class Auth {
    private $db;
    
    public function __construct() {
        require_once __DIR__ . '/Database.php';
        $this->db = new Database();
    }
    
    public function login($username, $password) {
        $sql = "SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1";
        $user = $this->db->fetch($sql, [$username, $username]);
        
        if ($user && password_verify($password, $user['password'])) {
            $this->startSession($user);
            return true;
        }
        
        return false;
    }
    
    public function register($data) {
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        return $this->db->insert('users', $data);
    }
    
    private function startSession($user) {
        session_start();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['logged_in'] = true;
    }
    
    public function isLoggedIn() {
        if (!isset($_SESSION)) {
            session_start();
        }
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }
    
    public function getCurrentUser() {
        if ($this->isLoggedIn()) {
            $sql = "SELECT id, username, email, role FROM users WHERE id = ?";
            return $this->db->fetch($sql, [$_SESSION['user_id']]);
        }
        return null;
    }
    
    public function logout() {
        session_start();
        session_destroy();
        return true;
    }
    
    public function hasRole($role) {
        if (!$this->isLoggedIn()) {
            return false;
        }
        return $_SESSION['role'] === $role;
    }
}
?>
