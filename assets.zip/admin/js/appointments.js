// Gerenciador de Agendamentos
class AppointmentManager {
    constructor() {
        this.calendar = null;
        this.appointments = [];
        this.modal = document.getElementById('appointmentModal');
        this.form = document.getElementById('appointmentForm');
        this.init();
    }

    async init() {
        await this.setupCalendar();
        await this.loadAppointments();
        this.setupEventListeners();
        this.setupFilters();
    }

    async setupCalendar() {
        const calendarEl = document.querySelector('.calendar-view');
        this.calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            events: [],
            eventClick: (info) => {
                this.showAppointmentDetails(info.event);
            },
            dateClick: (info) => {
                this.showNewAppointmentModal(info.date);
            }
        });
        this.calendar.render();
    }

    async loadAppointments() {
        try {
            const response = await fetch('../api/appointments.php');
            const data = await response.json();

            if (data.success) {
                this.appointments = data.data;
                this.renderAppointments();
                this.updateCalendar();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            this.showError('Erro ao carregar agendamentos: ' + error.message);
        }
    }

    renderAppointments() {
        const container = document.querySelector('.appointments-list');
        container.innerHTML = this.appointments.map(appointment => `
            <div class="appointment-card status-${appointment.status}">
                <div class="appointment-header">
                    <h3>${appointment.service_type}</h3>
                    <span class="appointment-status">${this.getStatusLabel(appointment.status)}</span>
                </div>
                <div class="appointment-details">
                    <p><i class="fas fa-user"></i> Cliente: ${appointment.client_name}</p>
                    <p><i class="fas fa-user-tie"></i> Advogado: ${appointment.lawyer_name}</p>
                    <p><i class="fas fa-calendar"></i> Data: ${this.formatDate(appointment.appointment_date)}</p>
                </div>
                <div class="appointment-actions">
                    ${this.getActionButtons(appointment)}
                </div>
            </div>
        `).join('');
    }

    updateCalendar() {
        const events = this.appointments.map(appointment => ({
            id: appointment.id,
            title: `${appointment.service_type} - ${appointment.client_name}`,
            start: appointment.appointment_date,
            className: `status-${appointment.status}`
        }));

        this.calendar.removeAllEvents();
        this.calendar.addEventSource(events);
    }

    setupEventListeners() {
        this.form.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.saveAppointment();
        });

        // Inicializa o date picker
        flatpickr("#appointment_date", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            minDate: "today",
            time_24hr: true
        });
    }

    setupFilters() {
        document.getElementById('dateFilter').addEventListener('change', () => this.filterAppointments());
        document.getElementById('statusFilter').addEventListener('change', () => this.filterAppointments());
        document.getElementById('lawyerFilter').addEventListener('change', () => this.filterAppointments());
    }

    async saveAppointment() {
        try {
            const formData = new FormData(this.form);
            const data = Object.fromEntries(formData.entries());

            const response = await fetch('../api/appointments.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                this.showSuccess('Agendamento realizado com sucesso');
                this.closeModal();
                await this.loadAppointments();
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            this.showError('Erro ao salvar agendamento: ' + error.message);
        }
    }

    async updateAppointmentStatus(id, status) {
        try {
            const response = await fetch(`../api/appointments.php?id=${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ status })
            });

            const result = await response.json();

            if (result.success) {
                this.showSuccess('Status atualizado com sucesso');
                await this.loadAppointments();
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            this.showError('Erro ao atualizar status: ' + error.message);
        }
    }

    getStatusLabel(status) {
        const labels = {
            'pending': 'Pendente',
            'confirmed': 'Confirmado',
            'cancelled': 'Cancelado',
            'completed': 'Concluído'
        };
        return labels[status] || status;
    }

    getActionButtons(appointment) {
        const buttons = [];

        if (appointment.status === 'pending') {
            buttons.push(`
                <button class="btn-confirm" onclick="appointmentManager.updateAppointmentStatus(${appointment.id}, 'confirmed')">
                    <i class="fas fa-check"></i> Confirmar
                </button>
            `);
        }

        if (appointment.status !== 'cancelled' && appointment.status !== 'completed') {
            buttons.push(`
                <button class="btn-cancel" onclick="appointmentManager.updateAppointmentStatus(${appointment.id}, 'cancelled')">
                    <i class="fas fa-times"></i> Cancelar
                </button>
            `);
        }

        if (appointment.status === 'confirmed') {
            buttons.push(`
                <button class="btn-complete" onclick="appointmentManager.updateAppointmentStatus(${appointment.id}, 'completed')">
                    <i class="fas fa-check-double"></i> Concluir
                </button>
            `);
        }

        return buttons.join('');
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showNewAppointmentModal(date = null) {
        if (date) {
            document.getElementById('appointment_date').value = date.toISOString().slice(0, 16);
        }
        this.modal.classList.add('show');
    }

    closeModal() {
        this.modal.classList.remove('show');
        this.form.reset();
    }

    showSuccess(message) {
        const alert = document.createElement('div');
        alert.className = 'alert alert-success';
        alert.textContent = message;
        document.querySelector('.alerts-container').appendChild(alert);
        setTimeout(() => alert.remove(), 3000);
    }

    showError(message) {
        const alert = document.createElement('div');
        alert.className = 'alert alert-error';
        alert.textContent = message;
        document.querySelector('.alerts-container').appendChild(alert);
        setTimeout(() => alert.remove(), 5000);
    }
}

// Inicializa o gerenciador de agendamentos
const appointmentManager = new AppointmentManager();
