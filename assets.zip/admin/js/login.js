document.getElementById('login-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('senha').value;
    const submitBtn = document.querySelector('.btn-login');
    
    try {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
        
        const response = await fetch('../api/login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: email,
                password: password
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Save session data if "remember me" is checked
            if (document.querySelector('input[name="lembrar"]').checked) {
                localStorage.setItem('user', JSON.stringify(data.user));
            }
            
            // Redirect to dashboard
            window.location.href = 'dashboard.html';
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        const errorMsg = document.createElement('div');
        errorMsg.className = 'error-message';
        errorMsg.textContent = error.message || 'Erro ao fazer login. Tente novamente.';
        
        const form = document.getElementById('login-form');
        form.insertBefore(errorMsg, form.firstChild);
        
        setTimeout(() => {
            errorMsg.remove();
        }, 5000);
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span>Entrar</span><i class="fas fa-arrow-right"></i>';
    }
});
