// Blog post management
class BlogManager {
    constructor() {
        this.postsContainer = document.querySelector('.blog-posts');
        this.postForm = document.getElementById('post-form');
        this.init();
    }
    
    async init() {
        this.loadPosts();
        this.setupEventListeners();
    }
    
    async loadPosts() {
        try {
            const response = await fetch('../api/blog.php');
            const data = await response.json();
            
            if (data.success) {
                this.renderPosts(data.data);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            this.showError('Error loading posts: ' + error.message);
        }
    }
    
    renderPosts(posts) {
        this.postsContainer.innerHTML = posts.map(post => `
            <div class="post-card" data-id="${post.id}">
                <div class="post-header">
                    <h3>${post.title}</h3>
                    <span class="post-status ${post.status}">${post.status}</span>
                </div>
                <div class="post-meta">
                    <span>By ${post.author_name}</span>
                    <span>${new Date(post.created_at).toLocaleDateString()}</span>
                </div>
                <div class="post-preview">${post.content.substring(0, 150)}...</div>
                <div class="post-actions">
                    <button class="btn-edit" onclick="blogManager.editPost(${post.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn-delete" onclick="blogManager.deletePost(${post.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                    <button class="btn-status" onclick="blogManager.toggleStatus(${post.id}, '${post.status}')">
                        <i class="fas fa-toggle-on"></i> 
                        ${post.status === 'draft' ? 'Publish' : 'Unpublish'}
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    setupEventListeners() {
        this.postForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const data = {
                title: formData.get('title'),
                content: formData.get('content'),
                status: formData.get('status')
            };
            
            try {
                const response = await fetch('../api/blog.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    this.showSuccess('Post created successfully');
                    this.loadPosts();
                    this.postForm.reset();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showError('Error creating post: ' + error.message);
            }
        });
    }
    
    async editPost(id) {
        // Implementation for editing posts
        const post = document.querySelector(`.post-card[data-id="${id}"]`);
        // Show edit form with post data
    }
    
    async deletePost(id) {
        if (confirm('Are you sure you want to delete this post?')) {
            try {
                const response = await fetch(`../api/blog.php?id=${id}`, {
                    method: 'DELETE'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    this.showSuccess('Post deleted successfully');
                    this.loadPosts();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showError('Error deleting post: ' + error.message);
            }
        }
    }
    
    async toggleStatus(id, currentStatus) {
        try {
            const newStatus = currentStatus === 'draft' ? 'published' : 'draft';
            
            const response = await fetch(`../api/blog.php?id=${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    status: newStatus
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(`Post ${newStatus === 'published' ? 'published' : 'unpublished'} successfully`);
                this.loadPosts();
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            this.showError('Error updating post status: ' + error.message);
        }
    }
    
    showSuccess(message) {
        const alert = document.createElement('div');
        alert.className = 'alert alert-success';
        alert.textContent = message;
        document.querySelector('.alerts-container').appendChild(alert);
        setTimeout(() => alert.remove(), 3000);
    }
    
    showError(message) {
        const alert = document.createElement('div');
        alert.className = 'alert alert-error';
        alert.textContent = message;
        document.querySelector('.alerts-container').appendChild(alert);
        setTimeout(() => alert.remove(), 5000);
    }
}

// Initialize blog manager
const blogManager = new BlogManager();
