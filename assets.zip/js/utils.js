// Utilitários gerais para o sistema
const Utils = {
    // Formatação de data e hora
    formatDate(date, format = 'short') {
        const options = {
            short: {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            },
            long: {
                day: '2-digit',
                month: 'long',
                year: 'numeric'
            },
            datetime: {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            }
        };
        return new Date(date).toLocaleDateString('pt-BR', options[format]);
    },

    // Sistema de notificações
    notifications: {
        show(message, type = 'info', duration = 3000) {
            const container = document.querySelector('.notifications-container') || 
                this.createNotificationContainer();

            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <i class="fas fa-${this.getIconForType(type)}"></i>
                <span>${message}</span>
            `;

            container.appendChild(notification);

            // Animação de entrada
            setTimeout(() => notification.classList.add('show'), 10);

            // Auto-remoção
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => notification.remove(), 300);
            }, duration);
        },

        createNotificationContainer() {
            const container = document.createElement('div');
            container.className = 'notifications-container';
            document.body.appendChild(container);
            return container;
        },

        getIconForType(type) {
            const icons = {
                success: 'check-circle',
                error: 'exclamation-circle',
                warning: 'exclamation-triangle',
                info: 'info-circle'
            };
            return icons[type] || 'info-circle';
        }
    },

    // Validações
    validate: {
        email(email) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        },

        cpf(cpf) {
            cpf = cpf.replace(/[^\d]/g, '');
            if (cpf.length !== 11) return false;

            // Validação do CPF
            let sum = 0;
            let rest;

            if (cpf === "00000000000") return false;

            for (let i = 1; i <= 9; i++) {
                sum = sum + parseInt(cpf.substring(i-1, i)) * (11 - i);
            }

            rest = (sum * 10) % 11;
            if (rest === 10 || rest === 11) rest = 0;
            if (rest !== parseInt(cpf.substring(9, 10))) return false;

            sum = 0;
            for (let i = 1; i <= 10; i++) {
                sum = sum + parseInt(cpf.substring(i-1, i)) * (12 - i);
            }

            rest = (sum * 10) % 11;
            if (rest === 10 || rest === 11) rest = 0;
            if (rest !== parseInt(cpf.substring(10, 11))) return false;

            return true;
        },

        phone(phone) {
            phone = phone.replace(/[^\d]/g, '');
            return phone.length >= 10 && phone.length <= 11;
        }
    },

    // Formatadores
    format: {
        currency(value) {
            return new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            }).format(value);
        },

        cpf(cpf) {
            return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/g, '$1.$2.$3-$4');
        },

        phone(phone) {
            phone = phone.replace(/[^\d]/g, '');
            if (phone.length === 11) {
                return phone.replace(/(\d{2})(\d{5})(\d{4})/g, '($1) $2-$3');
            }
            return phone.replace(/(\d{2})(\d{4})(\d{4})/g, '($1) $2-$3');
        }
    },

    // Requisições HTTP
    async http(url, options = {}) {
        try {
            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                },
                ...options
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Erro na requisição');
            }

            return data;
        } catch (error) {
            this.notifications.show(error.message, 'error');
            throw error;
        }
    },

    // Gerenciamento de formulários
    form: {
        getFormData(form) {
            const formData = new FormData(form);
            const data = {};
            for (let [key, value] of formData.entries()) {
                data[key] = value;
            }
            return data;
        },

        validate(form, rules) {
            const data = this.getFormData(form);
            const errors = {};

            for (let field in rules) {
                const value = data[field];
                const fieldRules = rules[field];

                if (fieldRules.required && !value) {
                    errors[field] = 'Campo obrigatório';
                    continue;
                }

                if (value) {
                    if (fieldRules.email && !Utils.validate.email(value)) {
                        errors[field] = 'E-mail inválido';
                    }
                    if (fieldRules.cpf && !Utils.validate.cpf(value)) {
                        errors[field] = 'CPF inválido';
                    }
                    if (fieldRules.phone && !Utils.validate.phone(value)) {
                        errors[field] = 'Telefone inválido';
                    }
                    if (fieldRules.minLength && value.length < fieldRules.minLength) {
                        errors[field] = `Mínimo de ${fieldRules.minLength} caracteres`;
                    }
                }
            }

            return {
                isValid: Object.keys(errors).length === 0,
                errors
            };
        },

        showErrors(form, errors) {
            // Remove mensagens de erro anteriores
            form.querySelectorAll('.error-message').forEach(el => el.remove());

            // Adiciona novas mensagens de erro
            for (let field in errors) {
                const input = form.querySelector(`[name="${field}"]`);
                if (input) {
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'error-message';
                    errorDiv.textContent = errors[field];
                    input.parentNode.appendChild(errorDiv);
                    input.classList.add('error');
                }
            }
        }
    },

    // Máscaras de input
    masks: {
        cpf(input) {
            input.addEventListener('input', (e) => {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length > 11) value = value.slice(0, 11);
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                e.target.value = value;
            });
        },

        phone(input) {
            input.addEventListener('input', (e) => {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length > 11) value = value.slice(0, 11);
                if (value.length > 2) value = `(${value.slice(0,2)}) ${value.slice(2)}`;
                if (value.length > 9) value = `${value.slice(0,9)}-${value.slice(9)}`;
                e.target.value = value;
            });
        },

        currency(input) {
            input.addEventListener('input', (e) => {
                let value = e.target.value.replace(/\D/g, '');
                value = (parseInt(value) / 100).toFixed(2);
                e.target.value = Utils.format.currency(value);
            });
        }
    }
};
