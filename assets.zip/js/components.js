// Componentes reutilizáveis
class Components {
    static init() {
        this.setupNotifications();
        this.setupModals();
        this.setupDropdowns();
        this.setupTabs();
    }

    // Sistema de Modal
    static modal(options) {
        const template = `
            <div class="modal ${options.class || ''}" id="${options.id}">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>${options.title}</h2>
                        <button class="close-modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        ${options.content}
                    </div>
                    ${options.footer ? `
                        <div class="modal-footer">
                            ${options.footer}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', template);
        const modal = document.getElementById(options.id);

        // Event listeners
        modal.querySelector('.close-modal').addEventListener('click', () => {
            this.closeModal(modal);
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.closeModal(modal);
            }
        });

        return {
            element: modal,
            open: () => this.openModal(modal),
            close: () => this.closeModal(modal)
        };
    }

    static openModal(modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    static closeModal(modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }

    // Componente de Table com ordenação e filtros
    static dataTable(options) {
        const table = document.createElement('div');
        table.className = 'data-table';
        table.innerHTML = `
            <div class="table-header">
                ${options.title ? `<h3>${options.title}</h3>` : ''}
                <div class="table-actions">
                    ${options.actions || ''}
                </div>
            </div>
            <div class="table-filters">
                <input type="text" class="search-input" placeholder="Pesquisar...">
                ${options.filters || ''}
            </div>
            <table>
                <thead>
                    <tr>
                        ${options.columns.map(col => `
                            <th class="${col.sortable ? 'sortable' : ''}" data-field="${col.field}">
                                ${col.label}
                                ${col.sortable ? '<i class="fas fa-sort"></i>' : ''}
                            </th>
                        `).join('')}
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
            <div class="table-pagination">
                <span class="pagination-info"></span>
                <div class="pagination-controls"></div>
            </div>
        `;

        const state = {
            data: options.data || [],
            currentPage: 1,
            itemsPerPage: options.itemsPerPage || 10,
            sortField: options.defaultSort?.field,
            sortDirection: options.defaultSort?.direction || 'asc'
        };

        function render() {
            const tbody = table.querySelector('tbody');
            const start = (state.currentPage - 1) * state.itemsPerPage;
            const end = start + state.itemsPerPage;
            
            let filteredData = [...state.data];
            
            // Aplicar filtros
            const searchTerm = table.querySelector('.search-input').value.toLowerCase();
            if (searchTerm) {
                filteredData = filteredData.filter(item => 
                    Object.values(item).some(val => 
                        String(val).toLowerCase().includes(searchTerm)
                    )
                );
            }

            // Ordenação
            if (state.sortField) {
                filteredData.sort((a, b) => {
                    const aVal = a[state.sortField];
                    const bVal = b[state.sortField];
                    return state.sortDirection === 'asc' ? 
                        (aVal > bVal ? 1 : -1) : 
                        (aVal < bVal ? 1 : -1);
                });
            }

            // Paginação
            const paginatedData = filteredData.slice(start, end);

            tbody.innerHTML = paginatedData.map(item => `
                <tr>
                    ${options.columns.map(col => `
                        <td>${col.render ? col.render(item) : item[col.field]}</td>
                    `).join('')}
                </tr>
            `).join('');

            // Atualizar informações da paginação
            const paginationInfo = table.querySelector('.pagination-info');
            paginationInfo.textContent = `Mostrando ${start + 1}-${Math.min(end, filteredData.length)} de ${filteredData.length}`;

            // Atualizar controles de paginação
            const totalPages = Math.ceil(filteredData.length / state.itemsPerPage);
            const controls = table.querySelector('.pagination-controls');
            controls.innerHTML = `
                <button ${state.currentPage === 1 ? 'disabled' : ''} data-page="prev">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <span>${state.currentPage} de ${totalPages}</span>
                <button ${state.currentPage === totalPages ? 'disabled' : ''} data-page="next">
                    <i class="fas fa-chevron-right"></i>
                </button>
            `;
        }

        // Event listeners
        table.addEventListener('click', (e) => {
            const th = e.target.closest('th.sortable');
            if (th) {
                const field = th.dataset.field;
                if (state.sortField === field) {
                    state.sortDirection = state.sortDirection === 'asc' ? 'desc' : 'asc';
                } else {
                    state.sortField = field;
                    state.sortDirection = 'asc';
                }
                render();
            }

            const pageBtn = e.target.closest('button[data-page]');
            if (pageBtn) {
                if (pageBtn.dataset.page === 'prev') {
                    state.currentPage--;
                } else {
                    state.currentPage++;
                }
                render();
            }
        });

        table.querySelector('.search-input').addEventListener('input', () => {
            state.currentPage = 1;
            render();
        });

        render();
        return table;
    }

    // Sistema de Tabs
    static tabs(options) {
        const container = document.createElement('div');
        container.className = 'tabs-container';
        container.innerHTML = `
            <div class="tabs-header">
                ${options.tabs.map((tab, index) => `
                    <button class="tab-button ${index === 0 ? 'active' : ''}" data-tab="${tab.id}">
                        ${tab.icon ? `<i class="fas fa-${tab.icon}"></i>` : ''}
                        ${tab.label}
                    </button>
                `).join('')}
            </div>
            <div class="tabs-content">
                ${options.tabs.map((tab, index) => `
                    <div class="tab-panel ${index === 0 ? 'active' : ''}" data-tab="${tab.id}">
                        ${tab.content}
                    </div>
                `).join('')}
            </div>
        `;

        container.addEventListener('click', (e) => {
            const button = e.target.closest('.tab-button');
            if (button) {
                const tabId = button.dataset.tab;
                container.querySelectorAll('.tab-button, .tab-panel').forEach(el => {
                    el.classList.toggle('active', el.dataset.tab === tabId);
                });
                if (options.onChange) {
                    options.onChange(tabId);
                }
            }
        });

        return container;
    }

    // Dropdown personalizado
    static dropdown(options) {
        const dropdown = document.createElement('div');
        dropdown.className = 'custom-dropdown';
        dropdown.innerHTML = `
            <button class="dropdown-toggle">
                ${options.label}
                <i class="fas fa-chevron-down"></i>
            </button>
            <div class="dropdown-menu">
                ${options.items.map(item => `
                    <a href="#" class="dropdown-item" data-value="${item.value}">
                        ${item.icon ? `<i class="fas fa-${item.icon}"></i>` : ''}
                        ${item.label}
                    </a>
                `).join('')}
            </div>
        `;

        dropdown.addEventListener('click', (e) => {
            if (e.target.closest('.dropdown-toggle')) {
                dropdown.classList.toggle('show');
            }
            
            const item = e.target.closest('.dropdown-item');
            if (item) {
                e.preventDefault();
                const value = item.dataset.value;
                dropdown.querySelector('.dropdown-toggle').textContent = item.textContent;
                dropdown.classList.remove('show');
                if (options.onChange) {
                    options.onChange(value);
                }
            }
        });

        document.addEventListener('click', (e) => {
            if (!dropdown.contains(e.target)) {
                dropdown.classList.remove('show');
            }
        });

        return dropdown;
    }

    // Inicialização geral de componentes
    static setupNotifications() {
        const container = document.createElement('div');
        container.className = 'notifications-container';
        document.body.appendChild(container);
    }

    static setupModals() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const modal = document.querySelector('.modal.show');
                if (modal) {
                    this.closeModal(modal);
                }
            }
        });
    }

    static setupDropdowns() {
        document.addEventListener('click', (e) => {
            const dropdowns = document.querySelectorAll('.custom-dropdown.show');
            dropdowns.forEach(dropdown => {
                if (!dropdown.contains(e.target)) {
                    dropdown.classList.remove('show');
                }
            });
        });
    }

    static setupTabs() {
        document.addEventListener('click', (e) => {
            const button = e.target.closest('.tab-button');
            if (button) {
                const container = button.closest('.tabs-container');
                const tabId = button.dataset.tab;
                container.querySelectorAll('.tab-button, .tab-panel').forEach(el => {
                    el.classList.toggle('active', el.dataset.tab === tabId);
                });
            }
        });
    }
}
