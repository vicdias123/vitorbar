class ClientArea {
    constructor() {
        this.currentSection = 'dashboard';
        this.init();
    }

    async init() {
        this.setupEventListeners();
        await this.loadUserData();
        await this.loadDashboardData();
    }

    setupEventListeners() {
        // Toggle do menu mobile
        document.querySelector('.menu-toggle').addEventListener('click', () => {
            document.querySelector('.sidebar').classList.toggle('show');
        });

        // Toggle do menu do usuário
        document.querySelector('.user-menu-btn').addEventListener('click', () => {
            document.querySelector('.user-dropdown').classList.toggle('show');
        });

        // Navegação
        document.querySelectorAll('.client-nav a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.getAttribute('href').substring(1);
                this.loadSection(section);
            });
        });

        // Logout
        document.getElementById('logoutBtn').addEventListener('click', (e) => {
            e.preventDefault();
            this.logout();
        });
    }

    async loadUserData() {
        try {
            const response = await fetch('../api/user-profile.php');
            const data = await response.json();

            if (data.success) {
                const user = data.data;
                document.getElementById('profileImage').src = user.profile_image || 'assets/img/default-avatar.png';
                document.getElementById('clientName').textContent = user.name;
                document.getElementById('userMenuName').textContent = user.name;
                document.getElementById('welcomeName').textContent = user.name;
            }
        } catch (error) {
            this.showError('Erro ao carregar dados do usuário');
        }
    }

    async loadDashboardData() {
        await Promise.all([
            this.loadUpcomingAppointments(),
            this.loadProcessStatus(),
            this.loadRecentDocuments(),
            this.loadRecentMessages()
        ]);
    }

    async loadUpcomingAppointments() {
        try {
            const response = await fetch('../api/appointments.php');
            const data = await response.json();

            if (data.success) {
                const container = document.querySelector('.upcoming-appointments');
                container.innerHTML = data.data
                    .filter(app => app.status === 'confirmed')
                    .slice(0, 3)
                    .map(app => `
                        <div class="appointment-item">
                            <div class="appointment-date">
                                <i class="fas fa-calendar"></i>
                                ${this.formatDate(app.appointment_date)}
                            </div>
                            <div class="appointment-info">
                                <strong>${app.service_type}</strong>
                                <span>Dr(a). ${app.lawyer_name}</span>
                            </div>
                        </div>
                    `).join('') || '<p>Nenhum agendamento próximo.</p>';
            }
        } catch (error) {
            this.showError('Erro ao carregar agendamentos');
        }
    }

    async loadProcessStatus() {
        // Implementar carregamento do status dos processos
    }

    async loadRecentDocuments() {
        try {
            const response = await fetch('../api/documents.php');
            const data = await response.json();

            if (data.success) {
                const container = document.querySelector('.recent-documents');
                container.innerHTML = data.data
                    .slice(0, 3)
                    .map(doc => `
                        <div class="document-item">
                            <i class="fas fa-file-alt"></i>
                            <div class="document-info">
                                <strong>${doc.title}</strong>
                                <span>${this.formatDate(doc.created_at)}</span>
                            </div>
                            <a href="${doc.file_path}" target="_blank">
                                <i class="fas fa-download"></i>
                            </a>
                        </div>
                    `).join('') || '<p>Nenhum documento recente.</p>';
            }
        } catch (error) {
            this.showError('Erro ao carregar documentos');
        }
    }

    async loadRecentMessages() {
        // Implementar carregamento das mensagens recentes
    }

    async loadSection(section) {
        this.currentSection = section;
        
        // Atualiza navegação
        document.querySelectorAll('.client-nav a').forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === `#${section}`);
        });

        // Carrega conteúdo da seção
        try {
            const response = await fetch(`sections/${section}.html`);
            const html = await response.text();
            document.querySelector('.page-content').innerHTML = html;

            // Inicializa funcionalidades específicas da seção
            switch(section) {
                case 'appointments':
                    this.initAppointments();
                    break;
                case 'documents':
                    this.initDocuments();
                    break;
                case 'profile':
                    this.initProfile();
                    break;
            }
        } catch (error) {
            this.showError('Erro ao carregar seção');
        }
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showError(message) {
        // Implementar sistema de notificações de erro
        console.error(message);
    }

    async logout() {
        try {
            await fetch('../api/logout.php');
            window.location.href = '../login.html';
        } catch (error) {
            this.showError('Erro ao fazer logout');
        }
    }
}

// Inicializa a área do cliente
const clientArea = new ClientArea();
