document.addEventListener('DOMContentLoaded', function() {
    // Inicializar gráficos
    initializeCharts();

    // Toggle Sidebar
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        });
    }

    // Filtros de Data
    const dateFilters = document.querySelectorAll('.btn-filter');
    dateFilters.forEach(filter => {
        filter.addEventListener('click', function() {
            dateFilters.forEach(f => f.classList.remove('active'));
            this.classList.add('active');
            updateDashboardData(this.textContent.toLowerCase());
        });
    });

    // Notificações
    const notificationBtn = document.querySelector('.notification-btn');
    if (notificationBtn) {
        notificationBtn.addEventListener('click', toggleNotifications);
    }
});

function initializeCharts() {
    // Gráfico de Leads por Área
    const leadsCtx = document.getElementById('leadsChart');
    if (leadsCtx) {
        new Chart(leadsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Direito Civil', 'Direito Trabalhista', 'Direito Empresarial', 'Direito Tributário'],
                datasets: [{
                    data: [35, 25, 20, 20],
                    backgroundColor: [
                        '#3498db',
                        '#2ecc71',
                        '#e74c3c',
                        '#f1c40f'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    // Gráfico de Agendamentos
    const schedulingCtx = document.getElementById('schedulingChart');
    if (schedulingCtx) {
        new Chart(schedulingCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
                datasets: [{
                    label: 'Agendamentos',
                    data: [65, 59, 80, 81, 56, 55],
                    borderColor: '#3498db',
                    tension: 0.4,
                    fill: true,
                    backgroundColor: 'rgba(52, 152, 219, 0.1)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

function updateDashboardData(period) {
    // Aqui você implementaria a lógica para atualizar os dados do dashboard
    // baseado no período selecionado (hoje, semana, mês)
    console.log(`Atualizando dados para o período: ${period}`);
}

function toggleNotifications() {
    // Implementar lógica para mostrar/esconder notificações
    const notifications = [
        {
            title: 'Novo Lead',
            message: 'João Silva solicitou contato - Direito Civil',
            time: '5 min atrás'
        },
        {
            title: 'Agendamento',
            message: 'Reunião com Maria Santos às 14h',
            time: '10 min atrás'
        },
        {
            title: 'Sistema',
            message: 'Backup realizado com sucesso',
            time: '1 hora atrás'
        }
    ];

    // Aqui você implementaria a lógica para mostrar estas notificações
    console.log('Notificações:', notifications);
}
