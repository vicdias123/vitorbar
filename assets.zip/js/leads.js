document.addEventListener('DOMContentLoaded', function() {
    // Inicializar Drag and Drop
    initializeDragAndDrop();

    // Formulário de Novo Lead
    const addLeadForm = document.getElementById('addLeadForm');
    if (addLeadForm) {
        addLeadForm.addEventListener('submit', handleNewLead);
    }

    // Inicializar Filtros
    initializeFilters();
});

function initializeDragAndDrop() {
    const draggables = document.querySelectorAll('.lead-card');
    const containers = document.querySelectorAll('.column-content');

    draggables.forEach(draggable => {
        draggable.addEventListener('dragstart', () => {
            draggable.classList.add('dragging');
        });

        draggable.addEventListener('dragend', () => {
            draggable.classList.remove('dragging');
            updateLeadCounts();
        });
    });

    containers.forEach(container => {
        container.addEventListener('dragover', e => {
            e.preventDefault();
            const afterElement = getDragAfterElement(container, e.clientY);
            const draggable = document.querySelector('.dragging');
            if (afterElement == null) {
                container.appendChild(draggable);
            } else {
                container.insertBefore(draggable, afterElement);
            }
        });
    });
}

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.lead-card:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function updateLeadCounts() {
    const columns = document.querySelectorAll('.kanban-column');
    columns.forEach(column => {
        const count = column.querySelectorAll('.lead-card').length;
        column.querySelector('.lead-count').textContent = count;
    });
}

function showAddLeadModal() {
    const modal = document.getElementById('addLeadModal');
    modal.classList.add('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
}

async function handleNewLead(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';

    try {
        // Simular envio ao backend
        await new Promise(resolve => setTimeout(resolve, 1000));

        const formData = new FormData(form);
        const leadData = Object.fromEntries(formData.entries());

        // Criar novo card de lead
        const newCard = createLeadCard(leadData);
        document.getElementById('novos').insertAdjacentHTML('afterbegin', newCard);

        // Atualizar contadores
        updateLeadCounts();

        // Reinicializar drag and drop
        initializeDragAndDrop();

        // Fechar modal e limpar formulário
        form.reset();
        closeModal('addLeadModal');

        showNotification('success', 'Lead adicionado com sucesso!');
    } catch (error) {
        showNotification('error', 'Erro ao adicionar lead. Tente novamente.');
    } finally {
        submitButton.disabled = false;
        submitButton.innerHTML = originalText;
    }
}

function createLeadCard(data) {
    return `
        <div class="lead-card" draggable="true">
            <div class="lead-priority high"></div>
            <div class="lead-info">
                <h4>${data.nome}</h4>
                <p>${data.area}</p>
                <small>${new Date().toLocaleDateString()}</small>
            </div>
            <div class="lead-actions">
                <button onclick="showLeadDetails('${data.email}')">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
        </div>
    `;
}

function showLeadDetails(leadId) {
    // Implementar visualização detalhada do lead
    console.log('Visualizar detalhes do lead:', leadId);
}

function initializeFilters() {
    const searchInput = document.querySelector('.search-leads input');
    const areaFilter = document.getElementById('areaFilter');
    const statusFilter = document.getElementById('statusFilter');
    const filterButton = document.querySelector('.btn-filter');

    if (searchInput) {
        searchInput.addEventListener('input', debounce(filterLeads, 300));
    }

    if (filterButton) {
        filterButton.addEventListener('click', filterLeads);
    }
}

function filterLeads() {
    const searchTerm = document.querySelector('.search-leads input').value.toLowerCase();
    const areaSelected = document.getElementById('areaFilter').value;
    const statusSelected = document.getElementById('statusFilter').value;

    const leads = document.querySelectorAll('.lead-card');
    
    leads.forEach(lead => {
        const leadText = lead.textContent.toLowerCase();
        const leadArea = lead.querySelector('.lead-info p').textContent.toLowerCase();
        const leadColumn = lead.closest('.kanban-column').id;

        const matchesSearch = searchTerm === '' || leadText.includes(searchTerm);
        const matchesArea = areaSelected === '' || leadArea.includes(areaSelected);
        const matchesStatus = statusSelected === '' || leadColumn.includes(statusSelected);

        lead.style.display = matchesSearch && matchesArea && matchesStatus ? 'block' : 'none';
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `admin-notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}
