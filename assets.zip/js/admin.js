document.addEventListener('DOMContentLoaded', function() {
    // Login Form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitButton = this.querySelector('button[type="submit"]');
            const originalText = submitButton.innerHTML;
            
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Autenticando...';

            // Simular uma requisição de login
            try {
                await new Promise(resolve => setTimeout(resolve, 1500)); // Simula delay da rede
                
                // Aqui você implementaria a lógica real de autenticação
                const email = this.email.value;
                const senha = this.senha.value;

                if (email === 'admin@exemplo.com' && senha === 'admin') {
                    showNotification('success', 'Login realizado com sucesso!');
                    setTimeout(() => {
                        window.location.href = 'dashboard.html';
                    }, 1000);
                } else {
                    showNotification('error', 'E-mail ou senha inválidos.');
                    submitButton.disabled = false;
                    submitButton.innerHTML = originalText;
                }
            } catch (error) {
                showNotification('error', 'Erro ao realizar login. Tente novamente.');
                submitButton.disabled = false;
                submitButton.innerHTML = originalText;
            }
        });
    }

    // Sistema de Notificações
    function showNotification(type, message) {
        const notification = document.createElement('div');
        notification.className = `admin-notification ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            ${message}
        `;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Animação dos inputs
    const inputs = document.querySelectorAll('.input-icon input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });

        // Manter o estado focused se o input já tiver valor
        if (input.value) {
            input.parentElement.classList.add('focused');
        }
    });
});
