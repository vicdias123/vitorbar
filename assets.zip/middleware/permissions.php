<?php
function checkPermission($requiredRole) {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
        header('HTTP/1.0 401 Unauthorized');
        echo json_encode([
            'success' => false,
            'message' => 'Não autorizado. Por favor, faça login.'
        ]);
        exit;
    }

    if (!in_array($_SESSION['role'], (array)$requiredRole)) {
        header('HTTP/1.0 403 Forbidden');
        echo json_encode([
            'success' => false,
            'message' => 'Você não tem permissão para acessar este recurso.'
        ]);
        exit;
    }

    return true;
}

function isOwnerOrAdmin($resourceUserId) {
    return $_SESSION['user_id'] == $resourceUserId || $_SESSION['role'] === 'admin';
}

function canAccessDocument($db, $documentId) {
    $sql = "SELECT d.*, u.role FROM documents d 
            JOIN users u ON d.uploaded_by = u.id 
            WHERE d.id = ?";
    $document = $db->fetch($sql, [$documentId]);

    if (!$document) {
        return false;
    }

    // Admins podem acessar qualquer documento
    if ($_SESSION['role'] === 'admin') {
        return true;
    }

    // O próprio cliente pode acessar seus documentos
    if ($document['client_id'] === $_SESSION['user_id']) {
        return true;
    }

    // Advogados podem acessar documentos dos seus clientes
    if ($_SESSION['role'] === 'lawyer') {
        $sql = "SELECT 1 FROM legal_cases 
                WHERE lawyer_id = ? AND client_id = ?";
        $isClientsLawyer = $db->fetch($sql, [$_SESSION['user_id'], $document['client_id']]);
        if ($isClientsLawyer) {
            return true;
        }
    }

    // Documentos públicos podem ser acessados por todos os usuários autenticados
    if (!$document['is_private']) {
        return true;
    }

    return false;
}

function canAccessCase($db, $caseId) {
    $sql = "SELECT * FROM legal_cases WHERE id = ?";
    $case = $db->fetch($sql, [$caseId]);

    if (!$case) {
        return false;
    }

    // Admins podem acessar qualquer processo
    if ($_SESSION['role'] === 'admin') {
        return true;
    }

    // O próprio cliente pode acessar seus processos
    if ($case['client_id'] === $_SESSION['user_id']) {
        return true;
    }

    // O advogado responsável pode acessar
    if ($case['lawyer_id'] === $_SESSION['user_id']) {
        return true;
    }

    return false;
}

// Função para registrar ações importantes no sistema
function logAction($db, $action, $details = []) {
    $data = [
        'user_id' => $_SESSION['user_id'],
        'action' => $action,
        'details' => json_encode($details),
        'ip_address' => $_SERVER['REMOTE_ADDR']
    ];

    $db->insert('activity_logs', $data);
}
