<?php
require_once __DIR__ . '/../classes/Auth.php';

class AuthMiddleware {
    private $auth;
    
    public function __construct() {
        $this->auth = new Auth();
    }
    
    public function requireAuth() {
        if (!$this->auth->isLoggedIn()) {
            header('Content-Type: application/json');
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'message' => 'Unauthorized access'
            ]);
            exit;
        }
    }
    
    public function requireRole($role) {
        $this->requireAuth();
        
        if (!$this->auth->hasRole($role)) {
            header('Content-Type: application/json');
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'message' => 'Insufficient permissions'
            ]);
            exit;
        }
    }
}

// Usage in API endpoints
if (basename($_SERVER['PHP_SELF']) !== 'login.php') {
    $authMiddleware = new AuthMiddleware();
    $authMiddleware->requireAuth();
}
?>
